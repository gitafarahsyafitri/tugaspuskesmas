<div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Pages</div>
                            <a class="nav-link" href="index.php?url=unitkerja">
                                <div class="sb-nav-link-icon"><i class="fas fa-print"></i></div>
                                Data Unit Kerja
                            </a>
                            <a class="nav-link" href="index.php?url=kelurahan">
                                <div class="sb-nav-link-icon"><i class="fas fa-building"></i></div>
                                Data Kelurahan
                           </a>
                            <a class="nav-link" href="index.php?url=pasien">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Data Pasien
                            </a>
                            <a class="nav-link" href="index.php?url=paramedik">
                                <div class="sb-nav-link-icon"><i class="fas fa-notes-medical"></i></div>
                                Data Paramedik
                            </a>
                            <a class="nav-link" href="index.php?url=periksa">
                                <div class="sb-nav-link-icon"><i class="fas fa-wrench"></i></div>
                                Data Periksa
                            </a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        gitasaf
                    </div>
                </nav>
            </div>